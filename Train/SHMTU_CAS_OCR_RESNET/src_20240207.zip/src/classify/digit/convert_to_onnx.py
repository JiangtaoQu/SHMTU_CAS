import torch.onnx

from src.classify.model.my_model import init_model
from src.config import config

model = init_model(config.model_digit_type, 10, False)

model.load_state_dict(torch.load('your_trained_resnet18_mnist.pth'))

model.eval()

# Create a dummy input tensor (1 image with 3 channel and size 224x224)
dummy_input = torch.randn(1, 3, 224, 224)

onnx_file_path = 'resnet18_mnist.onnx'

torch.onnx.export(model, dummy_input, onnx_file_path, verbose=True)

print(f'Model saved as {onnx_file_path}')
